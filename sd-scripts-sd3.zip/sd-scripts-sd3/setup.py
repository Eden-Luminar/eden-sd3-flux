from setuptools import setup, find_packages
 
setup(name = "library", packages = find_packages())